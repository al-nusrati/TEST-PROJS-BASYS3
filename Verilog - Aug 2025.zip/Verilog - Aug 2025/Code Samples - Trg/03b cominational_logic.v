//===================================================  
// Module: combinational_logic  
// Description:  
// - Implements basic combinational logic gates: AND, OR, XOR.  
// - Includes a 2-to-1 multiplexer.  
// - Uses **continuous assignment (`assign`)** for logic operations.  
// - Maps to different switches and LEDs on Basys 3.  
// - **Explicitly maps each switch to a specific function**, making it easier to assign individual switches for AND, OR, XOR, and MUX.  
// - **Avoids bit extraction (`SW[0]`, `SW[1]`, etc.)**, making the assignments more readable.  
//===================================================  

module combinational_logic (
    input  wire SW0,      // Switch 0 for AND gate
    input  wire SW1,      // Switch 1 for AND gate
    input  wire SW2,      // Switch 2 for OR gate
    input  wire SW3,      // Switch 3 for OR gate
    input  wire SW4,      // Switch 4 for XOR gate
    input  wire SW5,      // Switch 5 for XOR gate
    input  wire SW6,      // Multiplexer select line
    input  wire SW7,      // Multiplexer input A
    input  wire SW8,      // Multiplexer input B
    output wire LED0,     // LED 0 for AND gate output
    output wire LED1,     // LED 1 for OR gate output
    output wire LED2,     // LED 2 for XOR gate output
    output wire LED3      // LED 3 for Multiplexer output
);

    //-------------- Logic Gate Implementations --------------  
    /// **Continuous Assignment:** Logic gates operate combinationally
    assign LED0 = SW0 & SW1;  // AND gate output
    assign LED1 = SW2 | SW3;  // OR gate output
    assign LED2 = SW4 ^ SW5;  // XOR gate output

    //-------------- 2-to-1 Multiplexer --------------  
    /// **Multiplexer Logic:** Selects between SW7 and SW8 based on `SW6`
    assign LED3 = SW6 ? SW8 : SW7; 

endmodule

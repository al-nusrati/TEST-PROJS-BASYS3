//===================================================  
// Module: combinational_logic_non_wire  
// Description:  
// - Implements basic combinational logic gates: AND, OR, XOR.  
// - Includes a 2-to-1 multiplexer.  
// - Uses **always @(*) block instead of `assign`** for logic operations.  
// - Maps to different switches and LEDs on Basys 3.  
// - **Explicitly maps each switch to a specific function**, making it easier to assign individual switches for AND, OR, XOR, and MUX.  
// - **Avoids bit extraction (`SW[0]`, `SW[1]`, etc.)**, making the assignments more readable.  
// - **For non-wire version:** `assign` is replaced with `always @(*)` and output is changed from `wire` to `reg`.  
//===================================================  

module combinational_logic_non_wire (  
    input  SW0,      // Switch 0 for AND gate  
    input  SW1,      // Switch 1 for AND gate  
    input  SW2,      // Switch 2 for OR gate  
    input  SW3,      // Switch 3 for OR gate  
    input  SW4,      // Switch 4 for XOR gate  
    input  SW5,      // Switch 5 for XOR gate  
    input  SW6,      // Multiplexer select line  
    input  SW7,      // Multiplexer input A  
    input  SW8,      // Multiplexer input B  
    output reg LED0,     // LED 0 for AND gate output  
    output reg LED1,     // LED 1 for OR gate output  
    output reg LED2,     // LED 2 for XOR gate output  
    output reg LED3      // LED 3 for Multiplexer output  
);

    //-------------- Always Block for Logic Gates --------------  
    /// **Replaces `assign` with always @(*) block for combinational logic**  
    always @(*) begin  
        LED0 = SW0 & SW1;  // AND gate output  
        LED1 = SW2 | SW3;  // OR gate output  
        LED2 = SW4 ^ SW5;  // XOR gate output  
    end  

    //-------------- 2-to-1 Multiplexer --------------  
    /// **Multiplexer Logic:** Selects between SW7 and SW8 based on `SW6`  
    always @(*) begin  
        LED3 = SW6 ? SW8 : SW7;  
    end  

endmodule

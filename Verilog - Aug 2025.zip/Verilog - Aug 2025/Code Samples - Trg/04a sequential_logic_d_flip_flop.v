//===================================================  
// Module: sequential_logic_d_flip_flop  
// Description: Implements a D Flip-Flop with active-high reset  
// In Verilog, sequential logic refers to circuits whose output depends not only on the current inputs but also on past inputs.  
//  
// In Verilog, you need to code the behavior of the D flip-flop explicitly, as Verilog itself does not inherently define the behavior of flip-flops like D flip-flops.  
// The language provides constructs for describing hardware, but it doesn’t automatically create specific hardware components for you.  
//===================================================  

module sequential_logic_d_flip_flop (
    input wire clk,    // Clock input  
    input wire reset,  // Reset input (active high)  
    input wire d,      // Data input  
    output reg q       // Data output (registered)  
);

    //-------------- Flip-Flop Behavior --------------  
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            q <= 0;  // Reset output to 0  
        end else begin
            q <= d;  // Store input 'd' on the rising clock edge  
        end
    end

endmodule
//===================================================  
// Module: sequential_logic_counter  
// Description: Implements a 4-bit up counter  
// Inputs:  
//   - clk (BTN0): Clock signal to increment the counter  
//   - reset (BTN1): Asynchronous reset to clear the counter  
// Outputs:  
//   - count (LED3-LED0): 4-bit counter value displayed on LEDs  
//===================================================  

module sequential_logic_counter (
    input wire BTN0,       // Clock input from BTN0 (push-button 0)
    input wire BTN1,       // Reset input from BTN1 (push-button 1)
    output reg [3:0] LED   // 4-bit output to LED3-LED0 (Counter Value)
);

    // Counter behavior: Increment on rising clock edge or reset to 0
    always @(posedge BTN0 or posedge BTN1) begin
        if (BTN1) begin
            LED <= 4'b0000;  // Reset counter to 0
        end else begin
            LED <= LED + 1;  // Increment counter on clock edge
        end
    end

endmodule

//===================================================  
// Explanation:
// - Pressing BTN0 (Clock) increments the counter by 1.
// - Pressing BTN1 (Reset) clears the counter value (sets all bits to 0).
// - The current counter value is displayed on LED3-LED0 in real-time.

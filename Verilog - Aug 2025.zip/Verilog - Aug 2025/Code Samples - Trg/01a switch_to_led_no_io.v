//===================================================  
// Module: switch_to_led_no_io  
// Description:  
// - Internal simulation of switch-to-LED mapping.  
// - Does NOT use external inputs (`SW`) or outputs (`LED`).  
// - Uses internal registers for switch states and LED outputs.  
// - Intended for conceptual understanding, not actual FPGA use.  
//===================================================  

module switch_to_led_no_io;

    //-------------- Internal Registers --------------  
    // Simulated switch and LED values (no external connections)  
    reg switch0, switch1;  // Stores internal switch states  
    reg led0, led1;        // Internal registers for LED outputs  

    //-------------- Initial Block (Simulation Purpose) --------------  
    // Assign fixed values to simulate switches  
    initial begin
        switch0 = 1'b0;  // 1-bit binary value of 0 (Switch OFF)  
        switch1 = 1'b1;  // 1-bit binary value of 1 (Switch ON)  

        // Examples of binary values in Verilog:
        // 4'b1010  -> 4-bit value: 1010
        // 8'b00001111  -> 8-bit value: 00001111
        // 16'b1100_0011_1010_0101  -> 16-bit value with underscores for readability
    end

    //-------------- LED Assignment --------------  
    // Directly assign switch values to LEDs  
    always @(*) begin
        led0 = switch0;  // LED mirrors switch0 state  
        led1 = switch1;  // LED mirrors switch1 state  
    end

endmodule
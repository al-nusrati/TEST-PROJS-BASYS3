//===================================================  
// Module: combinational_logic  
// Description:  
// - Implements basic combinational logic gates: AND, OR, XOR.  
// - Includes a 2-to-1 multiplexer.  
// - Uses **continuous assignment (`assign`)** for logic operations.  
//===================================================  

module combinational_logic (
    input  wire A,        // Input A
    input  wire B,        // Input B
    input  wire sel,      // Multiplexer select line
    output wire and_out,  // AND gate output
    output wire or_out,   // OR gate output
    output wire xor_out,  // XOR gate output
    output wire mux_out   // 2-to-1 multiplexer output
);

    //-------------- Logic Gate Implementations --------------  
    /// **Continuous Assignment:** Logic gates operate combinationally
    assign and_out = A & B;  // AND gate
    assign or_out  = A | B;  // OR gate
    assign xor_out = A ^ B;  // XOR gate

    //-------------- 2-to-1 Multiplexer --------------  
    /// **Multiplexer Logic:** Selects between A and B based on `sel`
    assign mux_out = sel ? B : A; 

endmodule
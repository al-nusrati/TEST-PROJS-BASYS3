//===================================================  
// Module: switch_to_led_sequential  
// Description:  
// - Reads two switches (`SW[0]`, `SW[1]`) from Basys 3.  
// - Captures switch states into LEDs (`LED[0]`, `LED[1]`) on clock edge.  
// - Uses **sequential logic** (`always @(posedge clk)`), ensuring updates only on clock cycle.  
// - **Stores switch values in registers (flip-flops).**  
//===================================================  

module switch_to_led_sequential (
    output reg [1:0] LED,   // 2-bit LED output (LED[0], LED[1] on Basys 3 board)
    input  clk,            // Clock signal
    input  [1:0] SW        // 2-bit switch input (SW[0], SW[1] from Basys 3 board)
);

    //-------------- Always Block (Sequential Logic) --------------  
    /// `always @(posedge clk)` → **Sequential Block (Edge-Sensitive)**  
    /// - **Runs only on clock's rising edge (posedge clk).**  
    /// - **Stores switch states in LED registers on every clock cycle.**  
    always @(posedge clk) begin

        //-------------- LED Assignment --------------  
        // Capture switch values in LEDs on clock edge  
        // Using `<=` ensures proper flip-flop behavior and avoids race conditions  
        // `<=` is a **non-blocking assignment**, meaning all right-hand values are read first
        // before updating the left-hand side. This ensures assignments happen in parallel.  
        //
        // Example of race condition if `=` (blocking assignment) were used:
        // LED[0] = SW[0];   // Assigns SW[0] to LED[0] immediately
        // LED[1] = LED[0];  // LED[1] now gets the new LED[0], not original SW[0]
        //
        // With `<=`, both assignments use the original switch values before any update occurs.  
        LED[0] <= SW[0];   // LED0 captures Switch0 state on clock edge  
        LED[1] <= SW[1];   // LED1 captures Switch1 state on clock edge  

    end

endmodule

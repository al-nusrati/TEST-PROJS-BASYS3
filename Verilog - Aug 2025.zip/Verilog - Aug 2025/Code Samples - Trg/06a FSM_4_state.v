//===================================================  
// Module: fsm_4_state  
// Description: 4-state finite state machine  
//===================================================  

module fsm_4_state (
    input wire clk,     // Clock signal  
    input wire rst,     // Active-high reset  
    output reg [1:0] current_state  // FSM state output  
);

    //-------------- State Encoding --------------  
    typedef enum reg [1:0] {
        S_00 = 2'b00,  // State 00  (Initialization state)
        S_01 = 2'b01,  // State 01  (Processing state 1)
        S_10 = 2'b10,  // State 10  (Processing state 2)
        S_11 = 2'b11   // State 11  (Final state)
    } state_t;

    state_t state, next_state; // State registers  

    //-------------- State Transition Logic --------------  
    always @(posedge clk or posedge rst) begin
        if (rst)
            state <= S_00;  // Reset to initial state  
        else
            state <= next_state;
    end

    //-------------- Next State Logic --------------  
    always @(*) begin
        case (state)
            S_00: next_state = S_01;  
            S_01: next_state = S_10;  
            S_10: next_state = S_11;  
            S_11: next_state = S_00;  
            default: next_state = S_00;  
        endcase
    end

    //-------------- State Output Assignment --------------
    // Assign output state  
    always @(posedge clk) begin
        state <= current_state;
    end
    // note: we could have used "assign state = current_state", and it would have been slightly fast because it would be wired
    //       assign is for continuous assignments, which are used for combinational logic.
    //       assign would require state to be a wire, but state is a reg in this case.
    //       Using always @(posedge clk), we guarantee that state updates only on the rising edge of the clock.
    //       If assign were used, it would create combinational behavior, which is not desired for FSM state storage. 

endmodule

//===================================================  
// Explanation:  
// - This module implements a **4-state finite state machine (FSM)**.  
// - It cycles through states: **S_00 → S_01 → S_10 → S_11 → back to S_00**.  
// - Uses a **2-bit typedef enum** for state representation.  
// - The FSM transitions occur on the **rising edge of clk**.  
// - If **rst = 1**, the FSM resets to **S_00**.  
// - The **current state is assigned to the output** for monitoring.  
// - A **default case is added** to prevent unintended behavior.  
//===================================================  
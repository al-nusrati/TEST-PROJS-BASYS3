//===================================================  
// Module: sequential_logic_register  
// Description: Implements a 4-bit register  
// Inputs:  
//   - clk (BTN0): Clock signal to store the input value  
//   - reset (BTN1): Asynchronous reset to clear the register  
//   - data_in (SW3-SW0): 4-bit input data from switches  
// Outputs:  
//   - data_out (LED3-LED0): 4-bit stored value displayed on LEDs  
//===================================================  

module sequential_logic_register (
    input wire BTN0,       // Clock input from BTN0 (push-button 0)
    input wire BTN1,       // Reset input from BTN1 (push-button 1)
    input wire [3:0] SW,   // 4-bit input from SW3-SW0 (switches)
    output reg [3:0] LED   // 4-bit output to LED3-LED0 (LEDs)
);

    // Register behavior: store 'SW' on rising clock edge or reset to 0
    always @(posedge BTN0 or posedge BTN1) begin
        if (BTN1) begin
            LED <= 4'b0000;  // Reset register to 0
        end else begin
            LED <= SW;  // Store switch input on clock edge
        end
    end

    // Uncomment the following line to manually set the register value to 1111
    // assign LED = 4'b1111;  // Force LED output to 1111

endmodule

//===================================================  
// Explanation:
// - Pressing BTN0 (Clock) stores the current SW3-SW0 state into the register.
// - Pressing BTN1 (Reset) clears the stored value (sets all bits to 0).
// - The stored value is displayed in real-time on LED3-LED0.
// - Uncommenting `assign LED = 4'b1111;` will override all behavior and force LED output to 1111.
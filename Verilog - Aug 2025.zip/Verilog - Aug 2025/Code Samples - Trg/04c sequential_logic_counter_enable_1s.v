//===================================================  
// Module: sequential_logic_counter  
// Description: Implements a 4-bit up counter with a 1-second enable signal  
// Inputs:  
//   - clk (100MHz system clock): Used to generate a 1-second pulse  
// Outputs:  
//   - count (LED3-LED0): 4-bit counter value displayed on LEDs  
//===================================================  

module sequential_logic_counter (
    input wire clk,        // 100MHz system clock
    output reg [3:0] LED   // 4-bit output to LED3-LED0 (Counter Value)
);

    reg [26:0] counter = 0;  // 27-bit counter to generate 1-second pulse
    reg enable_1s = 0;       // 1-second enable signal

    always @(posedge clk) begin
        counter <= counter + 1;
        if (counter == 100_000_000) begin  // 100M cycles for 1 sec at 100MHz
            counter <= 0;
            enable_1s <= 1;  // Generate a 1-cycle pulse every second
        end else begin
            enable_1s <= 0;  // Reset pulse
        end
    end

    // Counter updates only when enable_1s is high
    always @(posedge clk) begin
        if (enable_1s) begin
            LED <= LED + 1;
        end
    end

endmodule

//===================================================  
// Explanation:
// - The first `always` block generates a **1-second pulse** using a counter.
// - `enable_1s` goes **high** for one clock cycle every second.
// - The second `always` block **increments the counter** only when `enable_1s` is high.
// - This structure is similar to calling a function every second.
//===================================================  
// Module: spi_master  
// Description: Write-only SPI Master for 8-bit data transfer over MOSI  
// You can start transferring data when cs is active and the clock is running.  
// This is a write-only SPI Master. No MISO or read-back support included.  
// We do not use data_valid as input — instead, the module handles one-time write upon instantiation.  
// Control Signals: cs (chip select), sclk (SPI clock)  
// Data Signals: data_din (8-bit input), mosi (serial output)  
//===================================================  

module spi_master(
    input wire clk,              // Clock input (e.g., 6.25 MHz)
    input wire reset,            // Synchronous reset
    input wire [7:0] data_din,   // 8-bit data input to send via SPI
    output wire cs,              // Chip Select (active low) 
    output wire sclk,            // SPI Clock (mirrors clk during transfer)
    output wire mosi             // Master Out Slave In
);

    //-------------- Internal Signals --------------
    reg [7:0] shift_reg;  // 8-bit shift register to hold data
    reg [3:0] bit_count;  // 4-bit counter for bit transmission
    reg cs_reg;           // Internal chip select register

    //-------------- SPI Clock Generation --------------
    assign sclk = clk;          // Use the 6.25 MHz clock for SPI clock

    //-------------- Data Shift Logic --------------
    always @(posedge clk or posedge reset) begin
        // on (posedge reset) --> the internal signals (shift_reg, bit_count, and cs_reg) are reset
        if (reset) begin
            shift_reg <= 8'b0;
            bit_count <= 4'b0;
            cs_reg    <= 1'b1;  // CS inactive
        end
        // on (posedge clk) -> transfers 1 bit every clk cycle
        else begin
            if (bit_count == 0) begin
                shift_reg <= data_din;  // Load new data
                cs_reg    <= 1'b0;      // Activate CS (active low for SPI) --> start shifting data
            end else if (bit_count < 8) begin
                shift_reg <= {shift_reg[6:0], 1'b0};  // Shift left
                bit_count <= bit_count + 1;
            end else begin
                cs_reg <= 1'b1;      // Deactivate CS after last bit
                bit_count <= 4'b0;   // Reset bit_count for next transfer
            end
        end
    end

    //-------------- SPI Output Assignments --------------
    assign mosi = shift_reg[7];  // Send MSB of shift_reg
    assign cs   = cs_reg;        // Chip select

endmodule // spi_master


//===================================================  
// Simplified Process Flow for SPI Transfer:
// 1. Load data into shift_reg from data_din.
// 2. Set cs to 0 (activate chip select).
// 3. Shift data out one bit at a time on mosi:
//    - First bit (MSB) is sent out on mosi.
//    - The shift register shifts left by 1 bit on each clock cycle.
//    - The bit count is incremented for each bit sent.
// 4. After 8 bits, set cs to 1 (deactivate chip select).
// 5. Reset bit_count to 0 and ready for the next data transfer.
//===================================================



/*
//===================================================  
// Usage: Example Instantiation of spi_master with 4 different 8-bit data transfers  
//===================================================  

module top_module (
    input wire clk,            // Clock input (e.g., 6.25 MHz)
    input wire reset,          // Reset input
    output wire mosi,          // MOSI output (Master Out Slave In)
    output wire sclk,          // SPI Clock output (SCLK)
    output wire cs             // Chip Select output (CS)
);

    // Define the 4 different 8-bit data to send via SPI
    reg [7:0] data_to_send_1 = 8'b11001010;  // Example data 1: 0xCA (11001010)
    reg [7:0] data_to_send_2 = 8'b10101101;  // Example data 2: 0xAD (10101101)
    reg [7:0] data_to_send_3 = 8'b11110000;  // Example data 3: 0xF0 (11110000)
    reg [7:0] data_to_send_4 = 8'b00011111;  // Example data 4: 0x1F (00011111)

    // Temporary register to hold the data being sent
    reg [7:0] current_data;

    // Instantiate the SPI master module in the top module
    spi_master spi_inst (
        .clk(clk),           // Connect the system clock to the SPI master module
        .reset(reset),       // Connect the reset signal
        .data_din(current_data), // Pass the current 8-bit data to be transferred via SPI
        .cs(cs),             // Connect chip select (cs) to the SPI master
        .sclk(sclk),         // Connect SPI clock (sclk) to the SPI master
        .mosi(mosi)          // Connect MOSI (Master Out Slave In) to the SPI master
    );

    // State machine or control logic to manage the sequential data transfers
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            current_data <= 8'b0;   // Reset current data to 0
        end else begin
            // Example: Sequential data transfers
            case (current_data)
                8'b00000000: current_data <= data_to_send_1;  // First data transfer
                data_to_send_1: current_data <= data_to_send_2;  // Second data transfer
                data_to_send_2: current_data <= data_to_send_3;  // Third data transfer
                data_to_send_3: current_data <= data_to_send_4;  // Fourth data transfer
                data_to_send_4: current_data <= 8'b00000000;  // Reset back to idle (if needed)
                default: current_data <= 8'b00000000;  // Default case for safety
            endcase
        end
    end

endmodule // top_module
*/


/*
//===================================================  
// Module: oled_text_display  
// Description: Display four different texts (AHMED, JAWAD, AASHIR, ABCD)  
//              in sequence on the OLED screen using SPI interface  
//              with a 1 Hz rate from clk_divider_multi  
//===================================================  

module oled_text_display (
    input wire clk,       // 100 MHz system clock
    input wire reset,     // Active-high synchronous reset
    output wire SPI_SCK,  // SPI Clock output
    output wire SPI_MOSI, // SPI Data output
    output wire SPI_CS    // SPI Chip Select output
);

    //-------------- Signal Declarations --------------  
    wire clk_1Hz;             // 1 Hz clock from clk_divider_multi
    wire clk_6_25MHz;         // 6.25 MHz SPI clock from clk_divider_multi
    reg [1:0] state;          // 2-bit state to cycle through texts
    reg [7:0] text_data;      // 8-bit data to send to OLED (each text is one byte)
    wire spi_ready;           // SPI ready signal to indicate when SPI is available for new data

    // Instance of clk_divider_multi for generating the 1 Hz and 6.25 MHz clocks
    clk_divider_multi clk_div_inst (
        .clk_in(clk),             // 100 MHz system clock input
        .reset(reset),            // Active-high synchronous reset
        .clk_1Hz(clk_1Hz),        // 1 Hz clock output
        .clk_6_25MHz(clk_6_25MHz), // 6.25 MHz clock output (used for SPI)
        .clk_1MHz(),              // Not used
        .clk_1kHz(),              // Not used
        .clk_50Hz()               // Not used
    );

    // Instance of SPI Master for communication with OLED
    spi_master #(
        .CLOCK_DIVIDER(10) // Adjust the clock divider if needed for the correct SPI frequency
    ) spi_inst (
        .clk(clk_6_25MHz),  // Use the 6.25 MHz clock for SPI communication
        .reset(reset),      // Reset
        .SPI_SCK(SPI_SCK),  // SPI Clock
        .SPI_MOSI(SPI_MOSI),// SPI Data out (MOSI)
        .SPI_CS(SPI_CS),    // SPI Chip Select
        .data_in(text_data), // 8-bit text data to send to OLED
        .data_ready(spi_ready) // SPI ready signal
    );

    //-------------- State Machine to Cycle Through Texts --------------  
    always @(posedge clk_1Hz or posedge reset) begin
        if (reset) begin
            state <= 2'b00;       // Reset state to the first text (AHMED)
            text_data <= 8'h41;   // Display "A" (ASCII 0x41)
        end else begin
            case (state)
                2'b00: begin
                    if (spi_ready) begin
                        state <= 2'b01;          // Transition to next state (JAWAD)
                        text_data <= 8'h48;      // Display "H" (ASCII 0x48)
                    end
                end
                2'b01: begin
                    if (spi_ready) begin
                        state <= 2'b10;          // Transition to next state (AASHIR)
                        text_data <= 8'h4D;      // Display "M" (ASCII 0x4D)
                    end
                end
                2'b10: begin
                    if (spi_ready) begin
                        state <= 2'b11;          // Transition to next state (ABCD)
                        text_data <= 8'h45;      // Display "E" (ASCII 0x45)
                    end
                end
                2'b11: begin
                    if (spi_ready) begin
                        state <= 2'b00;          // Back to the first state (AHMED)
                        text_data <= 8'h44;      // Display "D" (ASCII 0x44)
                    end
                end
                default: begin
                    state <= 2'b00;          // Default to first state
                    text_data <= 8'h41;      // Display "A"
                end
            endcase
        end
    end

endmodule
*/
//===================================================  
// Module: clk_divider_multi  
// Description: Universal clock divider for Basys 3  
//              Generates multiple frequencies from  
//              100 MHz input clock:  
//              - 6.25 MHz (for SPI)  
//              - 1 MHz    (general purpose)  
//              - 1 kHz    (7-segment display mux)  
//              - 1 Hz     (slow timer / blink)  
//              - 50 Hz    (button debounce sampling)  
//===================================================  

module clk_divider_multi (
    input  wire clk_in,         // **Input Clock**: 100 MHz system clock
    input  wire reset,          // **Sync Reset**: Active-high synchronous reset
    output reg  clk_6_25MHz,    // **Output Clock**: ~6.25 MHz for SPI
    output reg  clk_1MHz,       // **Output Clock**: 1 MHz
    output reg  clk_1kHz,       // **Output Clock**: 1 kHz (for 7-seg)
    output reg  clk_1Hz,        // **Output Clock**: 1 Hz
    output reg  clk_50Hz        // **Output Clock**: 50 Hz (for debounce)
);

//-------------- 6.25 MHz Divider --------------
reg [3:0] counter_6_25MHz;  // 4-bit counter for divide-by-16 logic

always @(posedge clk_in or posedge reset) begin
   // Main counter logic
   if (counter_6_25MHz == 4'd15) begin
      clk_6_25MHz <= ~clk_6_25MHz; // Toggle the output clock every 16 cycles
      counter_6_25MHz <= 4'b0;     // Reset counter after 16 cycles
   end
   else begin
      counter_6_25MHz <= counter_6_25MHz + 1; // Increment counter
   end
   
   // Reset part
   if (reset) begin
      counter_6_25MHz <= 4'b0;    // Reset counter to 0 on reset
      clk_6_25MHz <= 1'b0;        // Start with output low
   end
end

//-------------- 1 MHz Divider --------------
reg [6:0] counter_1MHz;  // 7-bit counter for divide-by-100 logic

always @(posedge clk_in or posedge reset) begin
    // Main counter logic
    if (counter_1MHz == 7'd99) begin
        clk_1MHz <= ~clk_1MHz; // Toggle the output clock every 100 cycles
        counter_1MHz <= 7'b0;  // Reset counter after 100 cycles
    end
    else begin
        counter_1MHz <= counter_1MHz + 1; // Increment counter
    end
    
    // Reset part
    if (reset) begin
        counter_1MHz <= 7'b0;   // Reset counter to 0 on reset
        clk_1MHz <= 1'b0;       // Start with output low
    end
end

//-------------- 1 kHz Divider --------------
reg [9:0] counter_1kHz;  // 10-bit counter for divide-by-1000 logic

always @(posedge clk_in or posedge reset) begin
    // Main counter logic
    if (counter_1kHz == 10'd999) begin
        clk_1kHz <= ~clk_1kHz; // Toggle the output clock every 1000 cycles
        counter_1kHz <= 10'b0;  // Reset counter after 1000 cycles
    end
    else begin
        counter_1kHz <= counter_1kHz + 1; // Increment counter
    end
    
    // Reset part
    if (reset) begin
        counter_1kHz <= 10'b0;  // Reset counter to 0 on reset
        clk_1kHz <= 1'b0;       // Start with output low
    end
end

//-------------- 1 Hz Divider --------------
reg [16:0] counter_1Hz;  // 17-bit counter for divide-by-100,000 logic

always @(posedge clk_in or posedge reset) begin
    // Main counter logic
    if (counter_1Hz == 17'd99999) begin
        clk_1Hz <= ~clk_1Hz; // Toggle the output clock every 100,000 cycles
        counter_1Hz <= 17'b0; // Reset counter after 100,000 cycles
    end
    else begin
        counter_1Hz <= counter_1Hz + 1; // Increment counter
    end
    
    // Reset part
    if (reset) begin
        counter_1Hz <= 17'b0;   // Reset counter to 0 on reset
        clk_1Hz <= 1'b0;        // Start with output low
    end
end

//-------------- 50 Hz Divider --------------
reg [13:0] counter_50Hz;  // 14-bit counter for divide-by-2000 logic

always @(posedge clk_in or posedge reset) begin
    // Main counter logic
    if (counter_50Hz == 14'd1999) begin
        clk_50Hz <= ~clk_50Hz; // Toggle the output clock every 2000 cycles
        counter_50Hz <= 14'b0;  // Reset counter after 2000 cycles
    end
    else begin
        counter_50Hz <= counter_50Hz + 1; // Increment counter
    end
    
    // Reset part
    if (reset) begin
        counter_50Hz <= 14'b0;   // Reset counter to 0 on reset
        clk_50Hz <= 1'b0;        // Start with output low
    end
end

endmodule // clk_divider_multi


//===================================================  
// Usage: Example Instantiation of clk_divider_multi  
//===================================================  
/*  
clk_divider_multi clk_div_inst (
    .clk_in(clk),             // 100 MHz system clock input
    .reset(reset),            // Active-high synchronous reset
    .clk_6_25MHz(my_spi_clk), // Using for SPI
    .clk_1MHz(),              // Not used
    .clk_1kHz(disp_clk),      // Using for 7-segment display multiplexing
    .clk_1Hz(),               // Not used
    .clk_50Hz()               // Not used (optional: for debounce)
);
*/
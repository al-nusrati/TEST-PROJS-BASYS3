//===================================================  
// Module: switch_to_led_wire  
// Description:  
// - Reads two switches (`SW[0]`, `SW[1]`) from Basys 3.  
// - Directly maps switch states to LEDs (`LED[0]`, `LED[1]`) using **wire**.  
// - Uses **continuous assignment (`assign`)**, eliminating the need for an `always` block.  
//===================================================  

module switch_to_led_wire (
    input  [1:0] SW,     // 2-bit switch input (SW[0], SW[1] from Basys 3 board)
    output wire [1:0] LED // 2-bit LED output (LED[0], LED[1] on Basys 3 board)
);

    //-------------- LED Assignment Using Wire --------------  
    /// **Continuous Assignment:**  
    /// - Uses `assign`, meaning LED output **always** follows the switch state  
    /// - No need for internal registers or `always` blocks  
    /// - We are not explicitly declaring `wire`, but in Verilog, an `output` without `reg` is implicitly a `wire`  
    assign LED = SW;  // LED mirrors the switch state directly

endmodule

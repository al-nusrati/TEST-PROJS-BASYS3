//===================================================  
// Module: fsm_four_state_debounced  
// Description: 4-State Finite State Machine with Debounced Button
//===================================================  

module fsm_four_state_debounced (
    input wire clk,     // 100MHz system clock (Basys 3)
    input wire rst,     // Active-high reset
    input wire next,    // Button input for state transition
    output reg [1:0] state // 2-bit state output
);

    //-------------- Internal Signals --------------  
    typedef enum reg [1:0] {
        S_00 = 2'b00,  // State 00
        S_01 = 2'b01,  // State 01
        S_10 = 2'b10,  // State 10
        S_11 = 2'b11   // State 11
    } state_t;

    state_t current_state, next_state;

    reg next_btn_d;    // Debounce register for button input
    reg next_btn_trig; // Trigger signal for button press (rising edge detected)

    //-------------- Debounce Logic --------------
    // Detects a clean rising edge of the `next` button input.
    always @(posedge clk) begin
        next_btn_d <= next;                     // Store the previous state of the button
        next_btn_trig <= next & ~next_btn_d;    // Trigger on rising edge
    end

    //-------------- State Transition Logic --------------
    // Updates the current state on the rising edge of the clock or reset.
    always @(posedge clk or posedge rst) begin
        if (rst)
            current_state <= S_00; // Reset to state 00
        else
            current_state <= next_state; // Move to the next state
    end

    //-------------- Next State Logic --------------
    // Combinational logic to determine the next state.
    // Transitions occur only when `next_btn_trig` is high.  
    // note:   Its combinational logic, not sequential.
    //         It generates simple combinational circuit (e.g. multiplexer)
    //         It updates only when input changes, meaning it doesn't consume clock cycles like a sequential block (always @(posedge clk)).
    always @(*) begin
        case (current_state)
            S_00: next_state = next_btn_trig ? S_01 : S_00;
            S_01: next_state = next_btn_trig ? S_10 : S_01;
            S_10: next_state = next_btn_trig ? S_11 : S_10;
            S_11: next_state = next_btn_trig ? S_00 : S_11;
            default: next_state = S_00;
        endcase
    end

    // Assign output state  
    always @(posedge clk) begin
        state <= current_state;
    end

//===================================================  
// Explanation:  
// - Uses the 100MHz clock from the Basys 3 board.  
// - Implements a **4-state FSM** with transitions in the sequence:  
//       **00 → 01 → 10 → 11 → back to 00.**  
// - **Debounce logic ensures stable button input:**  
//       - Button presses can generate unintended multiple transitions due to mechanical bouncing.  
//       - A flip-flop-based approach detects a **clean rising edge** of the `next` button.  
//       - Ensures only one valid state transition per button press.  
// - **Reset (`rst`) sets FSM back to `S_00`.**
//
// There are 4x always in parallel
//    *  update next_btn_trig : 1 (btn pressed) , 0 (otherwise)
//    *  update next_state when next_btn_trig = 1
//    *  update current_state = next_state
//    *  update state = current_state      (used in updating of next_state)
//===================================================
endmodule

/*
   XDC File Configuration (Modify Basys3_Master.xdc)

   ## Push Buttons
   set_property PACKAGE_PIN T18 [get_ports {rst}]
   set_property IOSTANDARD LVCMOS33 [get_ports {rst}]

   set_property PACKAGE_PIN W19 [get_ports {next}]
   set_property IOSTANDARD LVCMOS33 [get_ports {next}]

//---
   ✅ BTN0 → Reset (rst)
   ✅ BTN1 → Next State (next)
*/
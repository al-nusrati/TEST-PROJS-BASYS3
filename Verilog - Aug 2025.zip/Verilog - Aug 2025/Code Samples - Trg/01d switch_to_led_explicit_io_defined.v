//===================================================  
// Module: switch_to_led_explicit_io_defined  
// Description:  
// - Reads two switches (`SW[0]`, `SW[1]`) from Basys 3.  
// - Directly maps switch states to LEDs (`LED[0]`, `LED[1]`).  
// - Uses **combinational logic** (`always @(*)`), ensuring instant updates.  
// - **Implicitly assigns switch values to LEDs without internal registers.**  
//===================================================  

module switch_to_led_explicit_io_defined (
    output [1:0] LED,  // 2-bit LED output (LED[0], LED[1] on Basys 3 board)
    input  [1:0] SW    // 2-bit switch input (SW[0], SW[1] from Basys 3 board)
);

    //-------------- Always Block (Combinational Logic) --------------  
    /// `always @(*)` → **Combinational Block (Level-Sensitive)**  
    /// - **Runs whenever an input changes**, ensuring instant updates.  
    /// - This is **NOT** a sequential block (no clock involved).  
    /// - **Directly maps switch inputs to LEDs without extra registers.**  
    always @(*) begin
        //-------------- LED Assignment --------------  
        // Directly assign switch values to LEDs  
        // No intermediate storage → Switches control LEDs instantly  
        LED[0] = SW[0];  // LED0 mirrors Switch0 state  
        LED[1] = SW[1];  // LED1 mirrors Switch1 state  
    end

endmodule
//===================================================  
// Module: traffic_light_pedestrian_fsm  
// Description: FSM for Traffic Light with Pedestrian Crossing Signal  
//===================================================  

module traffic_light_pedestrian_fsm (
    input wire CLK,        // 100MHz system clock (Basys 3)
    input wire RESET,      // BTN0 - Asynchronous Reset
    output reg [2:0] LEDS, // Traffic Light Output (Red, Yellow, Green)
    output reg PED_LED     // Pedestrian Signal (1 = Walk, 0 = Don't Walk)
);

    //-------------- State Definitions --------------  
    typedef enum reg [1:0] {
        S_GREEN  = 2'b00,  // Green Light State (Cars Go, Pedestrians Wait)
        S_YELLOW = 2'b01,  // Yellow Light State (Cars Prepare to Stop)
        S_RED    = 2'b10   // Red Light State (Cars Stop, Pedestrians Cross)
    } state_t;
    
    state_t current_state, next_state;

    //-------------- Clock Divider (Approx. 1Hz) --------------  
    reg [26:0] counter;
    wire tick;

    parameter CLK_DIV = 100_000_000; // 100MHz / 1Hz = 100M

    always @(posedge CLK or posedge RESET) begin
        if (RESET)
            counter <= 0;
        else if (counter < CLK_DIV - 1)  // 100MHz / 1Hz = 100M
            counter <= counter + 1;
        else
            counter <= 0;
    end
    
    assign tick = (counter == CLK_DIV - 1); // Generates 1Hz pulse
    
    //-------------- State Transition Logic --------------  
    reg [3:0] timer;
    always @(posedge CLK or posedge RESET) begin
        if (RESET)
            current_state <= S_GREEN; // Start with Green on Reset
        else if (tick) begin
            if (timer == 0) 
                current_state <= next_state;
            else
                timer <= timer - 1;
        end
    end

    //-------------- Next State Logic & Timing Control --------------  
    always @(*) begin
        case (current_state)
            S_GREEN:  begin
                next_state = S_YELLOW;
                timer = 5; // Green Light for 5 seconds
            end
            S_YELLOW: begin
                next_state = S_RED;
                timer = 2; // Yellow Light for 2 seconds
            end
            S_RED:    begin
                next_state = S_GREEN;
                timer = 5; // Red Light for 5 seconds (Pedestrian Cross Time)
            end
            default:  begin
                next_state = S_GREEN;
                timer = 5;
            end
        endcase
    end

    //-------------- Output Logic (LEDS Control) --------------  
    always @(*) begin
        case (current_state)
            S_GREEN:  begin
                LEDS = 3'b001; // Green ON
                PED_LED = 0;   // Pedestrian must wait
            end
            S_YELLOW: begin
                LEDS = 3'b010; // Yellow ON
                PED_LED = 0;   // Pedestrian must still wait
            end
            S_RED:    begin
                LEDS = 3'b100; // Red ON
                PED_LED = 1;   // Pedestrians can cross
            end
            default:  begin
                LEDS = 3'b000;
                PED_LED = 0;
            end
        endcase
    end

//===================================================  
// Explanation:  
// - **FSM with 3 states**: Green → Yellow → Red → Green  
// - **Clock divider generates ~1Hz pulse** to time state transitions.  
// - **BTN0 (RESET) starts the cycle at Green.**  
// - **LEDS[2:0] represent traffic lights** (Red, Yellow, Green).  
// - **PED_LED controls pedestrian signal** (1 = Walk, 0 = Don't Walk).  
// - **Timing:** Green (5s), Yellow (2s), Red (5s for Pedestrians).  
//===================================================  

endmodule

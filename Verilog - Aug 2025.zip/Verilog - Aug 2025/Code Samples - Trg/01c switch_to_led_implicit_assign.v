//===================================================  
// Module: switch_to_led_assign  
// Description:  
// - Reads two switches (`SW[0]`, `SW[1]`) from Basys 3.  
// - Directly maps switch states to LEDs (`LED[0]`, `LED[1]`).  
// - Uses **continuous assignment (`assign`)**, ensuring instant updates.  
// - **No always block, no internal registers.**  
//===================================================  

module switch_to_led_assign (
    output [1:0] LED, // 2-bit LED output
    input  [1:0] SW   // 2-bit switch input
);

    /// **Continuous Assignment (`assign`)**
    /// - Directly links `SW` to `LED`
    /// - Ensures real-time updates **without an always block**
    assign LED = SW;

endmodule
//===================================================  
// Module: top_module  
// Description: Top-level module that prints four strings to the OLED using SPI  
// Strings to display: 
// - AHMED  
// - JAWAD  
// - AASHIR  
// - ABCD  
//===================================================  

module top_module(
    input wire clk,               // System clock (e.g., 50 MHz or 100 MHz)
    input wire reset,             // System reset
    output wire spi_sclk,         // SPI Clock (from spi_master)
    output wire spi_mosi,         // SPI MOSI (from spi_master)
    output wire spi_cs,           // SPI Chip Select (from spi_master)
    output wire spi_ready         // SPI Ready signal (from spi_master)
);

    //-------------- Internal Signals --------------  
    reg [7:0] string1 [0:4];      // Data for "AHMED"
    reg [7:0] string2 [0:5];      // Data for "JAWAD"
    reg [7:0] string3 [0:5];      // Data for "AASHIR"
    reg [7:0] string4 [0:3];      // Data for "ABCD"
    reg [3:0] state;              // State machine state
    reg [2:0] current_string;     // Current string index (0: AHMED, 1: JAWAD, 2: AASHIR, 3: ABCD)
    reg [3:0] char_index;         // Index of the character to be sent from the current string

    //-------------- Instantiate SPI Master --------------  
    spi_master spi_inst (
        .clk(clk),
        .reset(reset),
        .data_din(string1[char_index]),  // Dynamically changing data based on state
        .cs(spi_cs),
        .sclk(spi_sclk),
        .mosi(spi_mosi),
        .spi_ready(spi_ready)
    );

    //-------------- String Data Initialization --------------  
    initial begin  
        string1[0] = "A"; string1[1] = "H"; string1[2] = "M"; string1[3] = "E"; string1[4] = "D";  
        string2[0] = "J"; string2[1] = "A"; string2[2] = "W"; string2[3] = "A"; string2[4] = "D";  
        string3[0] = "A"; string3[1] = "A"; string3[2] = "S"; string3[3] = "H"; string3[4] = "I"; string3[5] = "R";  
        string4[0] = "A"; string4[1] = "B"; string4[2] = "C"; string4[3] = "D";  
    end  

    //-------------- State Machine for Sequencing Strings --------------  
    always @(posedge clk or posedge reset) begin  
        if (reset) begin  
            current_string <= 0;  // Start with "AHMED"  
            char_index <= 0;      // Start from the first character of the string  
            state <= 0;           // Initial state  
        end else if (spi_ready) begin  
            case (state)  
                0: begin  // Display "AHMED"  
                    if (char_index < 5) begin  
                        // Send next character of string1  
                        state <= 0;  
                    end else begin  
                        char_index <= 0;  
                        current_string <= 1;  // Switch to the next string ("JAWAD")  
                        state <= 1;  
                    end  
                end  
                1: begin  // Display "JAWAD"  
                    if (char_index < 5) begin  
                        // Send next character of string2  
                        state <= 1;  
                    end else begin  
                        char_index <= 0;  
                        current_string <= 2;  // Switch to the next string ("AASHIR")  
                        state <= 2;  
                    end  
                end  
                2: begin  // Display "AASHIR"  
                    if (char_index < 6) begin  
                        // Send next character of string3  
                        state <= 2;  
                    end else begin  
                        char_index <= 0;  
                        current_string <= 3;  // Switch to the next string ("ABCD")  
                        state <= 3;  
                    end  
                end  
                3: begin  // Display "ABCD"  
                    if (char_index < 4) begin  
                        // Send next character of string4  
                        state <= 3;  
                    end else begin  
                        char_index <= 0;  
                        current_string <= 0;  // Reset to the first string ("AHMED")  
                        state <= 0;           // Go back to displaying "AHMED"  
                    end  
                end  
            endcase  
            // Update char_index for the current string  
            case (current_string)  
                0: char_index <= char_index + 1;  // For "AHMED"  
                1: char_index <= char_index + 1;  // For "JAWAD"  
                2: char_index <= char_index + 1;  // For "AASHIR"  
                3: char_index <= char_index + 1;  // For "ABCD"  
            endcase  
        end  
    end  

endmodule // top_module

/*
Explanation:
Strings Setup: Four strings (AHMED, JAWAD, AASHIR, ABCD) are defined and initialized using registers. Each string is broken down into an array of characters, with each character stored as an 8-bit value (reg [7:0]).

State Machine: The state machine (state) controls the sequence of printing each string. It goes through states:

State 0: Displays "AHMED".

State 1: Displays "JAWAD".

State 2: Displays "AASHIR".

State 3: Displays "ABCD".

Character Transfer: For each state, the corresponding string is sent character by character to the spi_master module using the data_din input. The string to be transferred is dynamically selected by current_string, and char_index keeps track of which character in the string is currently being sent.

SPI Control: The SPI signals (sclk, mosi, cs) are passed to the spi_master instance. The spi_ready signal is used to know when it's safe to send the next character.

Wrap Around: After completing all four strings, the top module loops back to the first string ("AHMED") for continuous printing.

This top module will print the four strings to the OLED one after the other by controlling the SPI transfers. Let me know if you need any modifications!
*/


/*
//===================================================
// Module: top_module
// Description: Sends 4 pre-defined 14-character strings via SPI OLED
//===================================================

module top_module (
    input wire clk,             // 100 MHz system clock
    input wire reset,           // Synchronous reset
    output wire cs,             // Chip select for OLED
    output wire sclk,           // SPI clock
    output wire mosi            // SPI data output
);

    //-------------- Clock Divider for 6.25 MHz SPI Clock --------------
    wire clk_6M25;
    clk_divider #(16) clkdiv_inst (   // 100 MHz / 16 = 6.25 MHz
        .clk_in(clk),
        .reset(reset),
        .clk_out(clk_6M25)
    );

    //-------------- String Declarations --------------
    // Declare 4 strings of up to 14 characters (padded with spaces)
    reg [8*14-1:0] str_literal [0:3];     // 4 full string literals
    reg [7:0] str_array [0:3][0:13];      // 4x14 characters for SPI use

    //-------------- Initialization Block --------------
    integer i;
    initial begin
        // Assign string literals
        str_literal[0] = "AHMED         ";
        str_literal[1] = "JAWAD         ";
        str_literal[2] = "AASHIR        ";
        str_literal[3] = "ABCD          ";

        // Break into byte-wise array
        for (i = 0; i < 14; i = i + 1) begin
            str_array[0][i] = str_literal[0][8*(14-i)-1 -: 8];
            str_array[1][i] = str_literal[1][8*(14-i)-1 -: 8];
            str_array[2][i] = str_literal[2][8*(14-i)-1 -: 8];
            str_array[3][i] = str_literal[3][8*(14-i)-1 -: 8];
        end
    end

    //-------------- SPI Controller (You can add FSM here) --------------
    // This is where you'd cycle through str_array and pass each char
    // to an instance of spi_master like:
    // spi_master spi_inst(...);

endmodule

*/

//===================================================  
// Module: oled_text_display   
// Description: Minimal Verilog module to send text to Pmod OLEDrgb via SPI  
//              - Displays "AASHIR" (Large, Red) at Top-Left
//              - Displays "10" (Small, Blue) at Bottom-Right
//              - Uses SPI communication for OLED control
// Note: The Pmod uses the SSD1331 controller. 
// Inputs:  
//   - clk (100MHz system clock): Drives SPI timing  
// Outputs:  
//   - SPI signals for Pmod OLEDrgb:  
//===================================================  

module oled_text_display (
    input wire clk,        // 100MHz system clock
    output reg oled_clk,   // SPI Clock for OLED
    output reg oled_mosi,  // SPI Data for OLED
    output reg oled_dc,    // Data/Command Select for OLED
    output reg oled_res,   // Reset for OLED
    output reg oled_cs     // Chip Select for OLED
);

    //-------------- Internal Signals --------------  
    reg [6:0] spi_clk_div = 0; // Clock divider for SPI (1MHz)
    reg [7:0] spi_data;        // Data to be sent over SPI
    reg spi_transfer = 0;      // Indicates when to send SPI data
    reg [1:0] state;           // State machine for sequential execution

    //-------------- Cursor and Text Properties --------------      
    // OLED Display Parameters   
    reg [7:0] text_x, text_y;    // Cursor position  
    reg [15:0] text_color;       // Text color (RGB565)
    reg [3:0] font_size;         // Font size setting  

    //-------------- Text Strings as Packed Arrays / Text Data as Byte Arrays--------------  
    reg [8*MAX_LEN-1:0] text6_AASHIR = "AASHIR";   // 6 characters, 48 bits total
    reg [8*MAX_LEN-1:0] text2_10     = "10";

    //-------------- System and Design Constants --------------  
    localparam MAX_LEN = 10; // Maximum length of any string

    //-------------- OLED Command Set Constants --------------  
    localparam CMD_COL_ADDR   = 8'h15;  // Set column address
    localparam CMD_ROW_ADDR   = 8'h75;  // Set row address
    localparam CMD_COLOR_HIGH = 8'h5C;  // High byte of text color
    localparam CMD_COLOR_LOW  = 8'h5D;  // Low byte of text color
    localparam CMD_FONT_SIZE  = 8'h21;  // Set font size

    //-------------- Important Note on String Literals --------------  
    // In Verilog, string literals (e.g., "AASHIR") cannot be directly passed to tasks or functions.
    // Instead, they must be explicitly converted into a byte array (e.g., {"A", "A", "S", "H", "I", "R"}).
    // This is because Verilog does not support automatic conversion of string literals to byte arrays.
    // The byte array must be defined separately and passed to the task or function.
    //-------------- Text Data as Byte Arrays --------------  
    // reg [8*MAX_LEN-1:0] text6_AASHIR = "AASHIR";   // 6 characters, 48 bits total
    // reg [8*MAX_LEN-1:0] text2_10     = "10";

    //-------------- State Machine States --------------  
    localparam IDLE         = 2'b00;
    localparam PRINT_AASHIR = 2'b01;
    localparam PRINT_10     = 2'b10;

    //-------------- Always Block (Sequential Logic: SPI Clock Divider) --------------  
    always @(posedge clk) begin
        spi_clk_div <= spi_clk_div + 1;
        if (spi_clk_div == 49) begin  // 1MHz SPI clock (100MHz / 50) : 0-49 (50 counts total) & a full cycle (high + low) will take 100 clock cycles, which matches 1 MHz.
            spi_clk_div <= 0;
            oled_clk   <= ~oled_clk;  // Toggle SPI clock
        end
    end

    //-------------- Always Block (Sequential Logic: OLED Text Transmission) --------------
    // note: this is blocking code.  In order to have non-blocking (in parallel op), we should use 2 diff always
    always @(posedge oled_clk) begin
        if (!spi_transfer) begin
            Print_Aashir();   // Print "AASHIR" at the top-left corner
            Print_10();       // Print "10" at the bottom-right corner
            spi_transfer <= 1;
        end
    end

    //-------------- Task: Print "AASHIR" --------------  
    task Print_Aashir;
        begin
            // Set cursor position for "AASHIR"
            text_x <= 0;
            text_y <= 0;
            _send_command(CMD_COL_ADDR, text_x);  // Set column address
            _send_command(CMD_ROW_ADDR, text_y);  // Set row address

            // Set text properties for "AASHIR" (Large, Red, Top-Left)
            text_color <= 16'hF800;  // Red color
            font_size <= 2;          // Large font size
            _send_command(CMD_COLOR_HIGH, text_color[15:8]); // Send high byte of color
            _send_command(CMD_COLOR_LOW, text_color[7:0]);   // Send low byte of color
            _send_command(CMD_FONT_SIZE, font_size);         // Set font size

            // Introduce a delay using a counter
            repeat (10) @(posedge clk); // Wait for 10 clock cycles, to ensure the command is processed before sending data

            _send_text(text6_AASHIR, 6);
        end
    endtask

    //-------------- Task: Print "10" --------------  
    task Print_10;
        begin
            // Set cursor position for "10"
            text_x <= 80;
            text_y <= 50;
            _send_command(CMD_COL_ADDR, text_x);  // Set column address
            _send_command(CMD_ROW_ADDR, text_y);  // Set row address
            
            // Set text properties for "10" (Small, Blue, Bottom-Right)
            text_color <= 16'h001F;  // Blue color
            font_size <= 1;          // Small font size
            _send_command(CMD_COLOR_HIGH, text_color[15:8]); // Send high byte of color
            _send_command(CMD_COLOR_LOW, text_color[7:0]);   // Send low byte of color
            _send_command(CMD_FONT_SIZE, font_size);         // Set font size

            // Introduce a delay using a counter (b/w command and data)
            repeat (10) @(posedge clk); // Wait for 10 clock cycles, to ensure the command is processed before sending data

            _send_text(text2_10, 2);
        end
    endtask

   //-------------- Task: Send Text via SPI --------------
   // note: verilog doesn't allow dynamic inputs, so we pass text_len as input parameter
    task _send_text(input [8*MAX_LEN-1:0] text, input integer text_len);
      integer i;
      begin
         oled_cs <= 0;  // Enable OLED
         oled_dc <= 1;  // Data mode

         // Send each byte of the string
         for (i = 0; i < text_len; i = i + 1) begin
               _send_byte(text[i*8 +: 8]); // Extract each byte from the packed array ([i*8 +: 8] = sel 8 bits starting from i*8)
         end

         oled_cs <= 1;  // Disable OLED after sending text
         repeat (5) @(posedge clk); // Delay between transmissions
      end
    endtask

   //-------------- Task: Send Command via SPI --------------  
   task _send_command(input [7:0] command, input [7:0] data);
      begin
         oled_cs <= 0;  // Enable OLED

         oled_dc <= 0;        // Command mode
         _send_byte(command); // Send the command byte using _send_byte task
         repeat (5) @(posedge clk); // Delay between commands

         oled_dc <= 1;        // Switch to Data mode
         _send_byte(data);    // Send the data byte using _send_byte task
         repeat (5) @(posedge clk); // Delay between commands

         oled_cs <= 1;  // Disable OLED after command
      end
   endtask

   //========================================================  
   // SPI transmission logic for sending a single byte (sending the MSB first)
   task _send_byte(input [7:0] byte_data);
      integer bit_idx;
      begin
         for (bit_idx = 7; bit_idx >= 0; bit_idx = bit_idx - 1) begin
                oled_mosi <= byte_data[bit_idx]; // Set MOSI (idx is the index of bit in byte)
                oled_clk <= 1;                   // Clock high : data is typically latched into the slave device on the rising edge
                @(posedge clk);                  // Wait for system clock edge
                oled_clk <= 0;                   // Clock low : the falling edge (clock going low) marks the end of the transmission of one bit
                @(posedge clk);                  // Wait for system clock edge
                                                 // Small delay ensures that the slave device has had time to "see" the clock transition and prepare for the next bit
               //
               // Note: clock based timing (@(posedge clk)) is used instead of #1 (blocking delay)
               //       This makes code synthesizable; compatible with hardware.
               //       Using blocking delays like #1 makes the code non-portable between simulation and synthesis.
               //       It also makes the design less predictable and harder to debug.
         end
      end
   endtask

endmodule

   //  task _send_text(input [8*N-1:0] text); // N is the length of the string
   //      integer i;
   //      integer text_len;
   //      begin
   //          text_len = N;  // Calculate the length of the string

   //          oled_cs <= 0;  // Enable OLED
   //          oled_dc <= 1;  // Data mode

   //          // Send each byte of the string
   //          for (i = 0; i < text_len; i = i + 1) begin
   //              _send_byte(text[i*8 +: 8]); // Extract each byte from the packed array ([i*8 +: 8] = sel 8 bits starting from i*8)
   //          end

   //          oled_cs <= 1;  // Disable OLED after sending text
   //          repeat (5) @(posedge clk); // Delay between transmissions
   //      end
   //  endtask

   // task _send_text(input [7:0] text, input [3:0] text_len); // Accept packed array
   //    integer i;
   //    begin
   //       oled_cs <= 0;  // Enable OLED

   //       oled_dc <= 1;  // Data mode
   //       for (i = 0; i < text_len; i = i + 1) begin
   //             _send_byte(text[i*8 +: 8]);  // Extract each byte from the packed array
   //       end
         
   //       oled_cs <= 1;  // Disable OLED after sending text
   //       repeat (5) @(posedge clk); // Delay between data
   //    end
   // endtask

   // task _send_byte(input [7:0] byte_data);
   //    integer bit_idx;
   //    begin
   //       for (bit_idx = 7; bit_idx >= 0; bit_idx = bit_idx - 1) begin   // Send the MSB first
   //             oled_mosi <= byte_data[bit_idx]; // Set the bit to MOSI (idx is the index of bit in byte)
   //             oled_clk <= 1;                   // Clock high : data is typically latched into the slave device on the rising edge
   //             @(posedge clk); // Wait for the next system clock edge
   //             oled_clk <= 0;                   // Clock low : the falling edge (clock going low) marks the end of the transmission of one bit
   //             @(posedge clk); // Wait for the next system clock edge
   //                             // Small delay ensures that the slave device has had time to "see" the clock transition and prepare for the next bit
   //             //
   //             // Note: clock based timing (@(posedge clk)) is uses instead of #1 (blocking delay)
   //             //       This makes code synthesizable; compatible with hardware.
   //             //       Using blocking delays like #1 makes the code non-portable between simulation and synthesis.
   //             //       It also makes the design less predictable and harder to debug.
   //       end
   //    end
   // endtask

   // task _send_byte(input [7:0] byte_data);
   //    integer bit_idx;
   //    begin
   //       for (bit_idx = 7; bit_idx >= 0; bit_idx = bit_idx - 1) begin   // Send the MSB first
   //             oled_mosi <= byte_data[bit_idx]; // Set the bit to MOSI (idx is the index of bit in byte)
   //             oled_clk <= 1;                   // Clock high : data is typically latched into the slave device on the rising edge
   //             #1;  // Small delay (of 1 unit) to allow data capture
   //             oled_clk <= 0;                   // Clock low : the falling edge (clock going low) marks the end of the transmission of one bit
   //             #1;  // Small delay (of 1 unit) ensures that the slave device has had time to "see" the clock transition and prepare for the next bit
   //       end
   //    end
   // endtask


   //-------------- Task: Send Text via SPI --------------  
   //  task _send_text(input [7*8:0] text);
   //      integer i;
   //      begin
   //          oled_cs <= 0;  // Enable OLED
   //          oled_dc <= 1;  // Data mode
   //          for (i = 0; i < 7; i = i + 1) begin
   //              spi_data <= text[i*8 +: 8]; // Send each character
   //              oled_mosi <= spi_data[7];   // Send MSB first
   //          end
   //          oled_cs <= 1;  // Disable OLED after sending text
   //      end
   //  endtask


   //  task _send_text(input [7:0] text [0:6], input [3:0] text_len);  // input array of 7 elements, each elm is 8 bits : Adjust size and type as needed
   //      integer i;         // loop counter to iterate through each character in the text array
   //      begin
   //          oled_cs <= 0;  // Enable OLED
   //          oled_dc <= 1;  // Data mode
   //          for (i = 0; i < text_len; i = i + 1) begin                  // TODO
   //                spi_data <= text[i];       // Send each character
   //                oled_mosi <= spi_data[7];  // Send MSB first
   //                // SPI transmission logic here (bitwise)
   //          end
   //       end
   //          oled_cs <= 1;  // Disable OLED after sending text
   //  endtask



// task _send_text(input [7:0] text [0:6], input [3:0] text_len);  // Adjust size and type as needed
//     integer i, j;
//     reg [7:0] spi_data;
//     begin
//         oled_cs <= 0;  // Enable OLED (Chip Select)
//         oled_dc <= 1;  // Data mode
//         for (i = 0; i < text_len; i = i + 1) begin
//             spi_data <= text[i];  // Send each character from the text array
            
//             // SPI transmission logic (bitwise) to send the 8 bits of the character
//             for (j = 7; j >= 0; j = j - 1) begin
//                 oled_mosi <= spi_data[j];   // Send each bit starting from MSB
//                 oled_clk <= 1;              // Activate SPI clock (rising edge)
//                 #1 oled_clk <= 0;           // Deactivate SPI clock (falling edge)
//                 #1;                         // Small delay for stable transmission
//             end
//         end
//         oled_cs <= 1;  // Disable OLED after sending all the text (Chip Select)
//     end
// endtask

   // // Task to send text
   // task _send_text(input [7:0] text [0:6], input [3:0] text_len);
   //    integer i;
   //    begin
   //       oled_cs <= 0;  // Enable OLED
   //       oled_dc <= 1;  // Data mode
   //       for (i = 0; i < text_len; i = i + 1) begin
   //             send_byte(text[i]);  // Send each byte using send_byte task
   //       end
   //       oled_cs <= 1;  // Disable OLED after sending text
   //    end
   // endtask
   // // SPI transmission logic for sending a single byte
   // task send_byte(input [7:0] byte_data);
   //    integer bit_idx;
   //    begin
   //       for (bit_idx = 7; bit_idx >= 0; bit_idx = bit_idx - 1) begin   // send the MSB first
   //             oled_mosi <= byte_data[bit_idx]; // Set the bit to MOSI (idx is the index of bit in byte)
   //             oled_clk <= 1;                   // Clock high : data is typically latched into the slave device on the rising edge
   //             #1;  // Small delay (of 1 unit) to allow data capture
   //             oled_clk <= 0;                   // Clock low : the falling edge (clock going low) marks the end of the transmission of one bit
   //             #1;  // Small delay (of 1 unit) ensures that the slave device has had time to "see" the clock transition and prepare for the next bit
   //       end
   //    end
   // endtask


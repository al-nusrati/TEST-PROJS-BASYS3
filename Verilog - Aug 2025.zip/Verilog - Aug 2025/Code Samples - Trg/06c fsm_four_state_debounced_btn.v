//===================================================  
// Module: fsm_four_state_debounced_btn  
// Description: 4-State Finite State Machine with Debounced BTN1 (Next) and BTN0 (Reset)  
//===================================================  

module fsm_four_state_debounced_btn (
    input wire clk,          // 100MHz system clock (Basys 3)
    input wire btn0,         // BTN0 (Active-high reset)
    input wire btn1,         // BTN1 (Button input for state transition)
    output reg [1:0] state   // 2-bit state output
);

    //-------------- Internal Signals --------------  
    typedef enum reg [1:0] {
        S_00 = 2'b00,  // State 00
        S_01 = 2'b01,  // State 01
        S_10 = 2'b10,  // State 10
        S_11 = 2'b11   // State 11
    } state_t;

    state_t current_state, next_state;

    reg next_btn_d;    // Debounce register for button input
    reg next_btn_trig; // Trigger signal for button press (rising edge detected)

    //-------------- Debounce Logic --------------  
    // Detects a clean rising edge of BTN1 (Next button)
    always @(posedge clk) begin
        next_btn_d <= btn1;                     // Store the previous state of BTN1
        next_btn_trig <= btn1 & ~next_btn_d;    // Trigger on rising edge
    end

    //-------------- State Transition Logic --------------  
    // Updates the current state on the rising edge of the clock or reset (BTN0)
    always @(posedge clk or posedge btn0) begin
        if (btn0)
            current_state <= S_00; // Reset to state 00
        else
            current_state <= next_state; // Move to the next state
    end

    //-------------- Next State Logic --------------  
    // Combinational logic to determine the next state.
    always @(*) begin
        case (current_state)
            S_00: next_state = next_btn_trig ? S_01 : S_00;
            S_01: next_state = next_btn_trig ? S_10 : S_01;
            S_10: next_state = next_btn_trig ? S_11 : S_10;
            S_11: next_state = next_btn_trig ? S_00 : S_11;
            default: next_state = S_00;
        endcase
    end

    // Assign output state  
    always @(posedge clk) begin
        state <= current_state;
    end

//===================================================  
// Explanation:  
// - Uses the **100MHz clock** from the Basys 3 board.  
// - Implements a **4-state FSM** with transitions in the sequence:  
//       **00 → 01 → 10 → 11 → back to 00.**  
// - **BTN0 (reset) and BTN1 (next) are directly used without modifying XDC file.**  
// - **Debounce logic ensures stable button input:**  
//       - Button presses can generate unintended multiple transitions due to mechanical bouncing.  
//       - A flip-flop-based approach detects a **clean rising edge** of BTN1.  
//       - Ensures only one valid state transition per button press.  
// - **Reset (`btn0`) sets FSM back to `S_00`.**  
//  
// There are **4 always blocks running in parallel**:  
//    *  `next_btn_trig` updates (1 when BTN1 pressed, 0 otherwise)  
//    *  `next_state` updates when `next_btn_trig` = 1  
//    *  `current_state = next_state` (FSM state updates)  
//    *  `state = current_state` (drives output state)  
//===================================================  

endmodule
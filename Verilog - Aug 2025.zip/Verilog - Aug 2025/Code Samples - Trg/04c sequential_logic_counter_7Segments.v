//===================================================  
// Module: sequential_logic_counter  
// Description: Implements a 4-bit up counter with a 1-second clock and displays on LEDs & 7-segment display  
// Inputs:  
//   - clk (100MHz system clock): Used to generate a 1-second pulse  
// Outputs:  
//   - count (LED3-LED0): 4-bit counter value displayed on LEDs  
//   - seg (Seven-segment display output)  
//   - an (Anode signals for 7-segment multiplexing)  
//===================================================  

module sequential_logic_counter (
    input wire clk,        // 100MHz system clock
    output reg [3:0] LED,  // 4-bit output to LED3-LED0 (Counter Value)
    output reg [6:0] seg,  // 7-segment display output (active low)
    output reg [3:0] an    // Anode control for 7-segment display (active low)
);

    //-------------- Internal Signals --------------  
    reg [26:0] counter = 0;  // 27-bit counter to generate 1-second pulse
    reg [3:0] bcd_ones = 0;  // Ones place for 7-segment display
    reg [3:0] bcd_tens = 0;  // Tens place for 7-segment display
    reg [6:0] seg_lookup [0:9]; // Lookup table for 7-segment display
    reg [3:0] an_init = 4'b1111; // Initial anode values

    //-------------- Initial Block (Preload Constants) --------------  
    initial begin
        // Predefine 7-Segment Values
        seg_lookup[0] = 7'b1000000; // '0'
        seg_lookup[1] = 7'b1111001; // '1'
        seg_lookup[2] = 7'b0100100; // '2'
        seg_lookup[3] = 7'b0110000; // '3'
        seg_lookup[4] = 7'b0011001; // '4'
        seg_lookup[5] = 7'b0010010; // '5'
        seg_lookup[6] = 7'b0000010; // '6'
        seg_lookup[7] = 7'b1111000; // '7'
        seg_lookup[8] = 7'b0000000; // '8'
        seg_lookup[9] = 7'b0010000; // '9'
        
        // Initialize 7-Segment Display Anode Control
        an = an_init;
        an[0] = 0; // Enable first digit (ones place)
        an[1] = 0; // Enable second digit (tens place)
    end

    //-------------- Always Block (Sequential Logic: Clock Divider & Counter) --------------  
    always @(posedge clk) begin
        counter <= counter + 1;
        if (counter == 100_000_000) begin  // 100M cycles for 1 sec at 100MHz
            counter <= 0;
            LED <= LED + 1;  // Increment counter every second
            
            // BCD Conversion
            if (bcd_ones == 9) begin
                bcd_ones <= 0;
                bcd_tens <= bcd_tens + 1;
            end else begin
                bcd_ones <= bcd_ones + 1;
            end
        end
    end

    //-------------- Always Block (Combinational Logic: 7-Segment Display) --------------  
    // Fetch 7-segment pattern from lookup table
    always @(*) begin
        seg = seg_lookup[bcd_ones];
    end

endmodule

//===================================================  
// Explanation:
// - Uses the 100MHz clock from the Basys 3 board.
// - A 27-bit counter generates a 1-second pulse.
// - Each second, the counter increments and updates LED3-LED0.
// - The counter value is converted to BCD (ones & tens digits).
// - A lookup table is preloaded with 7-segment display values.
// - The 7-segment display shows the count using multiplexing.
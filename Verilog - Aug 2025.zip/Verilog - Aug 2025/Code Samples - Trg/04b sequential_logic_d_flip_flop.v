//===================================================  
// Module: sequential_logic_d_flip_flop  
// Description: Implements a simple D Flip-Flop  
// Inputs:  
//   - clk: Clock signal from BTN0 (push-button 0)  
//   - reset: Reset signal from BTN1 (push-button 1)  
//   - d: Data input from SW0 (switch 0)  
// Outputs:  
//   - q: Output to LED0 (LED 0)  
//===================================================  

module sequential_logic_d_flip_flop (
    input wire BTN0,   // Clock input from BTN0 (push-button 0)
    input wire BTN1,   // Reset input from BTN1 (push-button 1)
    input wire SW0,    // Data input from SW0 (switch 0)
    output reg LED0    // Output to LED0 (LED 0)
);

    // Flip-Flop behavior: store input 'd' on rising clock edge or reset to 0
    always @(posedge BTN0 or posedge BTN1) begin
        if (BTN1) begin
            LED0 <= 0;  // Reset output to 0
        end else begin
            LED0 <= SW0;  // Store input 'SW0' on the rising clock edge
        end
    end

endmodule

//===================================================  
// Explanation:
// - BTN0: The push-button (BTN0) is used as the clock for the flip-flop.
// - BTN1: The push-button (BTN1) is used as the asynchronous reset for the flip-flop.
// - SW0: The switch (SW0) controls the data input. It determines the stored value in the flip-flop.
// - LED0: The LED (LED0) displays the current state of the flip-flop's output.
//
// Why Direct References Are Clear:
// - Using names like SW0, BTN0, and LED0 makes it easy to identify the components on the Basys 3 board.
// - Vivado automatically maps these references to the corresponding pins via the default XDC file.
// - This approach simplifies the code since the pin assignments are handled by Vivado and the XDC file.


//===================================================  
// Summary of How This All Works Together:
// - The Verilog code describes how the FPGA should behave (flip-flop, clock, reset, data input).
// - Vivado synthesizes the Verilog code into hardware logic (gates, flip-flops).
// - The XDC file maps the physical components (BTN0, BTN1, SW0, LED0) to FPGA pins.
// - The bitstream configures the FPGA with the logic, which is then connected to the Basys 3 board components.
// - When you press buttons or toggle switches, the FPGA responds according to your Verilog code, controlling the LED output.
// - In essence, Verilog is describing hardware behavior, Vivado turns it into physical connections, and the FPGA executes that behavior on actual hardware.
